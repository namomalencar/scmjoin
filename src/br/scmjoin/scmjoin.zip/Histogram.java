package br.scmjoin;

public class Histogram {
	String valBigFreq="";
	int bigFreq=0;
	String valSmallFreq="";
	int smallFreq=0;
	int avgFreq=0;
	int distinctValues=0;

}
