package br.scmjoin;

public class MainThreadJoin {
	


}
